1. Visita la web para tu token de POSITIONSTACK para crear una cuenta y obtener una api key
2. Visita la web para tu token de OPENWEATHER para crear una cuenta y obtener una api key.
3. Visita la web para tu token de WUNDERGROUND para crear una cuenta y obtener una api key
4. Visita la web para tu token de WINDY para crear una cuenta y obtener una api key
5. Actualiza LAS variables de entornos en el archivo .env con tus api keys
6. En la consola, ve al directorio donde está el proyecto.
7. Ejecuta:

```bash
  npm install
```

8. Ejecuta:

```bash
  npm run start:clima-app
```
